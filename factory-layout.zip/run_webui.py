#!/usr/bin/env python
"""Run the Factory Layout WebUI server."""
import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "webui.app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        reload_dirs=["webui"],
    )
