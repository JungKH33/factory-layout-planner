from __future__ import annotations

import math
import warnings
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import gymnasium as gym
import torch
import torch.nn.functional as F


GroupId = Union[int, str]
RectI = Tuple[int, int, int, int]  # (x0,y0,x1,y1) half-open (json-style)


@dataclass
class FacilityGroup:
    id: GroupId
    width: float   # footprint width
    height: float  # footprint height
    movable: bool = True
    rotatable: bool = True
    # Constraint attributes (do NOT conflict with footprint width/height):
    # - facility_height: vertical height for ceiling constraint (invalid where map < value)
    # - facility_weight: weight for weight-zone constraint (invalid where map < value)
    # - facility_dry: dry/air-condition requirement level (invalid where map > value)
    # Default values chosen so no constraint is applied when unspecified:
    # - height/weight: -inf → (map < -inf) is always False
    # - dry: inf → (map > inf) is always False
    facility_height: float = float('-inf')
    facility_weight: float = float('-inf')
    facility_dry: float = float('inf')
    # IO relative offsets (CENTER-based local coordinates).
    # These are rotated with the facility (multiples of 90 degrees) and added to the world center.
    ent_rel_x: float = 0.0
    ent_rel_y: float = 0.0
    exi_rel_x: float = 0.0
    exi_rel_y: float = 0.0
    # Clearance (asymmetric): L/R/B/T paddings for placement constraints.
    # NOTE: Clearance is in grid-cell units and MUST be integer-valued.
    facility_clearance_left: int = 0
    facility_clearance_right: int = 0
    facility_clearance_bottom: int = 0
    facility_clearance_top: int = 0
    # Placement area constraint: list of placement_area IDs this group is allowed to be placed in.
    # None means no restriction (can be placed anywhere subject to other constraints).
    allowed_areas: Optional[List[str]] = None


class FactoryLayoutEnv(gym.Env):
    """Tensor-first Gymnasium env for factory layout placement.

    Design notes:
    - The engine owns placement feasibility, constraints, and objective evaluation.
    - Action semantics / candidate generation are owned by wrapper envs.
    - Observations are torch.Tensors (GPU-friendly; TorchRL-compatible).
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        *,
        grid_width: int,
        grid_height: int,
        groups: Dict[GroupId, FacilityGroup],
        group_flow: Optional[Dict[GroupId, Dict[GroupId, float]]] = None,
        # Forbidden areas: [{"rect": [x0, y0, x1, y1]}, ...]
        forbidden_areas: Optional[List[Dict[str, Any]]] = None,
        # --- zone/constraint configs (optional; fully map-based) ---
        # For each constraint, we define a per-cell float map:
        # - map is initialized from env.default_*
        # - areas override map values on their rects
        # Constraint invalidation is map comparison (same shape for all three):
        # - Weight/Height: invalid if map < facility_value
        # - Dry (reverse): invalid if map > facility_value
        default_weight: float = float("inf"),
        default_height: float = float("inf"),
        default_dry: float = -float("inf"),
        weight_areas: Optional[List[Dict[str, Any]]] = None,  # [{"rect":[x0,y0,x1,y1], "value": float}, ...]
        height_areas: Optional[List[Dict[str, Any]]] = None,  # [{"rect":[...], "value": float}, ...]
        dry_areas: Optional[List[Dict[str, Any]]] = None,  # [{"rect":[...], "value": float}, ...]
        placement_areas: Optional[List[Dict[str, Any]]] = None,  # [{"id": str, "rect":[x0,y0,x1,y1]}, ...]
        device: Optional[torch.device] = None,
        max_steps: Optional[int] = None,
        cost_scale: float = 100.0,
        penalty_weight: float = 50000.0,
        log: bool = False,
    ):
        super().__init__()
        self.grid_width = int(grid_width)
        self.grid_height = int(grid_height)
        self.groups = dict(groups)
        self.group_flow = group_flow or {}
        self.forbidden_areas = list(forbidden_areas or [])
        self.default_weight = float(default_weight)
        self.default_height = float(default_height)
        self.default_dry = float(default_dry)
        self.weight_areas = list(weight_areas or [])
        self.height_areas = list(height_areas or [])
        self.dry_areas = list(dry_areas or [])
        self.placement_areas = list(placement_areas or [])
        self.device = device or (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))
        self.max_steps = max_steps
        self.cost_scale = float(cost_scale)
        self.penalty_weight = float(penalty_weight)
        self.log = bool(log)

        # Engine does not own action semantics. Wrappers define action_space/obs additions.
        self.action_space = gym.spaces.Discrete(1)
        self.observation_space = gym.spaces.Dict({})

        # --- static id/index mapping (useful across wrappers) ---
        self.node_ids: List[GroupId] = sorted(self.groups.keys(), key=lambda x: str(x))
        self.gid_to_idx: Dict[GroupId, int] = {gid: i for i, gid in enumerate(self.node_ids)}

        # NOTE: positions store (x_bl, y_bl, rot) where (x_bl,y_bl) is the bottom-left
        # of the rotated AABB footprint, in integer grid-cell coordinates.
        self.positions: Dict[GroupId, Tuple[int, int, int]] = {}
        self.placed: set[GroupId] = set()
        self.remaining: List[GroupId] = []
        self._step_count = 0

        # Cached tensor maps (performance).
        self._static_invalid = self._build_static_invalid()
        self._occ_invalid = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        # Clearance invalid layer accumulated from already-placed facilities (body padded by their own clearance).
        self._clear_invalid = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        # next-gid dependent invalid layer (zones / constraints)
        self._zone_invalid = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        self._invalid = self._static_invalid.clone()

        # Pre-rasterized per-cell value maps (float32) for fast updates.
        self._weight_map = self._build_value_map(self.default_weight, self.weight_areas)
        self._height_map = self._build_value_map(self.default_height, self.height_areas)
        self._dry_map = self._build_value_map(self.default_dry, self.dry_areas)

        # Placement area masks: id → bool[H,W] where True = inside this area.
        self._placement_area_masks: Dict[str, torch.Tensor] = self._build_placement_area_masks()

        # Ensure invalid is consistent even before first reset.
        self._recompute_invalid()

    # ---- rect/zone helpers ----
    def _build_value_map(self, default_value: float, areas: List[Dict[str, Any]]) -> torch.Tensor:
        """Return float32[H,W] value map. Unspecified cells use `default_value`.

        Expected area format: {"rect": (x0,y0,x1,y1), "value": float}
        """
        m = torch.full(
            (self.grid_height, self.grid_width),
            float(default_value),
            dtype=torch.float32,
            device=self.device,
        )
        for a in areas:
            if not isinstance(a, dict):
                continue
            rect = a.get("rect", None)
            v = a.get("value", None)
            if rect is None or v is None:
                continue
            x0, y0, x1, y1 = rect
            x0 = max(0, min(self.grid_width, int(x0)))
            x1 = max(0, min(self.grid_width, int(x1)))
            y0 = max(0, min(self.grid_height, int(y0)))
            y1 = max(0, min(self.grid_height, int(y1)))
            if x1 > x0 and y1 > y0:
                m[y0:y1, x0:x1] = float(v)
        return m

    def _build_placement_area_masks(self) -> Dict[str, torch.Tensor]:
        """Build bool[H,W] masks for each placement_area. True = inside the area."""
        masks: Dict[str, torch.Tensor] = {}
        for area in self.placement_areas:
            if not isinstance(area, dict):
                continue
            aid = str(area.get("id", ""))
            if not aid:
                continue
            rect = area.get("rect", None)
            if rect is None:
                continue
            x0, y0, x1, y1 = rect
            x0 = max(0, min(self.grid_width, int(x0)))
            x1 = max(0, min(self.grid_width, int(x1)))
            y0 = max(0, min(self.grid_height, int(y0)))
            y1 = max(0, min(self.grid_height, int(y1)))
            m = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
            if x1 > x0 and y1 > y0:
                m[y0:y1, x0:x1] = True
            masks[aid] = m
        return masks

    def _clearance_lrtb(self, g: FacilityGroup, rot: int) -> Tuple[float, float, float, float]:
        """Return (cL,cR,cB,cT) clearance for a group, accounting for rotation.

        Clearance is integer-valued in grid-cell units. Rotation is restricted to multiples of 90
        degrees; 180/270 are supported for correctness even if callers primarily use 0/90.
        """
        cL = self._as_int(g.facility_clearance_left, name="facility_clearance_left")
        cR = self._as_int(g.facility_clearance_right, name="facility_clearance_right")
        cB = self._as_int(g.facility_clearance_bottom, name="facility_clearance_bottom")
        cT = self._as_int(g.facility_clearance_top, name="facility_clearance_top")
        r = self._norm_rot(rot)
        if r == 90:
            # left'  <- bottom, right' <- top, bottom' <- right, top' <- left
            return (cB, cT, cR, cL)
        if r == 180:
            return (cR, cL, cT, cB)
        if r == 270:
            return (cT, cB, cL, cR)
        return (cL, cR, cB, cT)

    def _update_zone_invalid_for_next(self) -> None:
        """Update `_zone_invalid` based on the *next* group (self.remaining[0])."""
        self._zone_invalid.zero_()
        if not self.remaining:
            self._recompute_invalid()
            return

        gid = self.remaining[0]
        g = self.groups.get(gid, None)
        if g is None:
            self._recompute_invalid()
            return

        # Unified map-based invalidation:
        # - Weight/Height: invalid where map < facility_value
        # - Dry (reverse): invalid where map > facility_value
        self._zone_invalid |= (self._weight_map < float(g.facility_weight))
        self._zone_invalid |= (self._height_map < float(g.facility_height))
        self._zone_invalid |= (self._dry_map > float(g.facility_dry))

        # Placement area constraint: if group has allowed_areas, invalidate outside those areas.
        allowed = getattr(g, "allowed_areas", None)
        if allowed is not None and len(allowed) > 0:
            # Union of allowed placement area masks
            allowed_mask = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
            for aid in allowed:
                if aid in self._placement_area_masks:
                    allowed_mask |= self._placement_area_masks[aid]
            # Invalidate everywhere outside the allowed areas
            self._zone_invalid |= (~allowed_mask)

        self._recompute_invalid()

    def _zone_invalid_for_gid(self, gid: GroupId) -> torch.Tensor:
        """Return zone-invalid map (bool[H,W]) as if `gid` were the next group.

        Used for reset-time ordering heuristics (does not mutate env state).
        """
        z = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        g = self.groups.get(gid, None)
        if g is None:
            return z

        z |= (self._weight_map < float(g.facility_weight))
        z |= (self._height_map < float(g.facility_height))
        z |= (self._dry_map > float(g.facility_dry))

        # Placement area constraint
        allowed = getattr(g, "allowed_areas", None)
        if allowed is not None and len(allowed) > 0:
            allowed_mask = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
            for aid in allowed:
                if aid in self._placement_area_masks:
                    allowed_mask |= self._placement_area_masks[aid]
            z |= (~allowed_mask)

        return z

    def get_placeable_mask(self, gid: GroupId, rot: int = 0) -> torch.Tensor:
        """conv2d로 전체 그리드의 배치 가능 마스크 계산 (fully vectorized).
        
        is_placeable과 동일한 로직:
        - body가 _invalid에 겹치면 안됨
        - body가 _clear_invalid에 겹치면 안됨
        - pad(clearance)가 _invalid에 겹치면 안됨
        - boundary 체크는 conv2d 출력 크기로 자동 처리
        
        Args:
            gid: 그룹 ID
            rot: rotation (0, 90, 180, 270)
        
        Returns:
            torch.Tensor: [H, W] bool, result[y, x] = True면 (x, y)에 배치 가능
        """
        if gid not in self.groups:
            return torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        
        g = self.groups[gid]
        rot = self._norm_rot(rot)
        
        w, h = self.rotated_size(g, rot)
        w, h = int(w), int(h)
        cL, cR, cB, cT = self._clearance_lrtb(g, rot)
        cL, cR, cB, cT = int(cL), int(cR), int(cB), int(cT)
        
        kw = w + cL + cR  # pad 전체 너비
        kh = h + cB + cT  # pad 전체 높이
        
        H, W = self.grid_height, self.grid_width
        result = torch.zeros((H, W), dtype=torch.bool, device=self.device)
        
        if kh > H or kw > W or h <= 0 or w <= 0:
            return result
        
        # invalid maps
        inv_f = self._invalid.float().unsqueeze(0).unsqueeze(0)
        clear_f = self._clear_invalid.float().unsqueeze(0).unsqueeze(0)
        
        # kernels
        body_kernel = torch.ones((1, 1, h, w), device=self.device, dtype=torch.float32)
        pad_kernel = torch.ones((1, 1, kh, kw), device=self.device, dtype=torch.float32)
        
        # conv2d
        body_inv = F.conv2d(inv_f, body_kernel, padding=0).squeeze()    # [H-h+1, W-w+1]
        body_clear = F.conv2d(clear_f, body_kernel, padding=0).squeeze()
        pad_inv = F.conv2d(inv_f, pad_kernel, padding=0).squeeze()      # [H-kh+1, W-kw+1]
        
        valid_h = H - kh + 1
        valid_w = W - kw + 1
        
        if valid_h <= 0 or valid_w <= 0:
            return result
        
        # body 결과를 pad 좌표계로 변환 (슬라이싱)
        # bottom-left (x,y) 기준에서 body 시작은 (x+cL, y+cB)
        body_inv_slice = body_inv[cB:cB+valid_h, cL:cL+valid_w]
        body_clear_slice = body_clear[cB:cB+valid_h, cL:cL+valid_w]
        
        # 조합: 모두 0이어야 배치 가능 (fully vectorized!)
        valid_mask = (body_inv_slice == 0) & (body_clear_slice == 0) & (pad_inv == 0)
        
        result[:valid_h, :valid_w] = valid_mask
        return result

    def count_placeable(self, gid: GroupId, rot: int = 0) -> int:
        """배치 가능한 위치 개수 반환.
        
        Args:
            gid: 그룹 ID
            rot: rotation (0, 90, 180, 270)
        
        Returns:
            int: 배치 가능한 위치 개수
        """
        mask = self.get_placeable_mask(gid, rot)
        return int(mask.sum().item())

    def is_placeable_batch(
        self, *, gid: GroupId, x: object, y: object, rot: object
    ) -> torch.Tensor:
        """주어진 좌표들의 배치 가능 여부 batch 검사 (fully vectorized).
        
        estimate_delta_obj와 동일한 인터페이스 (scalar/tensor 모두 지원).
        
        Args:
            gid: 그룹 ID
            x: x 좌표 (scalar 또는 tensor)
            y: y 좌표 (scalar 또는 tensor)
            rot: rotation (scalar 또는 tensor)
        
        Returns:
            torch.Tensor: [N] bool (scalar 입력 시 [1])
        """
        scalar_input = not (torch.is_tensor(x) or torch.is_tensor(y) or torch.is_tensor(rot))
        
        if scalar_input:
            x = torch.tensor([int(x)], dtype=torch.long, device=self.device)
            y = torch.tensor([int(y)], dtype=torch.long, device=self.device)
            rot = torch.tensor([int(rot)], dtype=torch.long, device=self.device)
        
        x = x.to(device=self.device, dtype=torch.long).view(-1)
        y = y.to(device=self.device, dtype=torch.long).view(-1)
        rot = rot.to(device=self.device, dtype=torch.long).view(-1)
        
        H, W = self.grid_height, self.grid_width
        N = x.numel()
        
        # rotation별 mask 생성 (0/180은 동일, 90/270은 동일)
        mask_0 = self.get_placeable_mask(gid, 0)
        mask_90 = self.get_placeable_mask(gid, 90)
        
        # 범위 체크
        in_bounds = (x >= 0) & (x < W) & (y >= 0) & (y < H)
        
        # rotation별 결과
        rot_norm = torch.remainder(rot, 360)
        is_rot0 = (rot_norm == 0) | (rot_norm == 180)
        
        # mask 인덱싱 (clamp로 범위 내로)
        x_clamped = x.clamp(0, W - 1)
        y_clamped = y.clamp(0, H - 1)
        
        result_0 = mask_0[y_clamped, x_clamped]
        result_90 = mask_90[y_clamped, x_clamped]
        
        result = torch.where(is_rot0, result_0, result_90)
        result = result & in_bounds
        
        return result

    @staticmethod
    def _as_int(v: object, *, name: str) -> int:
        """Coerce integer-valued inputs (int or float with .0) to int, else raise.

        This avoids silent rounding bugs when we commit to integer grid coordinates.
        """
        if isinstance(v, bool):
            raise ValueError(f"{name} must be int-like, got bool")
        if isinstance(v, int):
            return int(v)
        if isinstance(v, float) and v.is_integer():
            return int(v)
        raise ValueError(f"{name} must be int-like (e.g., 3 or 3.0), got {v!r}")

    @staticmethod
    def _norm_rot(rot: int) -> int:
        r = int(rot) % 360
        if r % 90 != 0:
            raise ValueError(f"rot must be a multiple of 90 degrees, got {rot!r}")
        return r

    @classmethod
    def rotated_size(cls, group: FacilityGroup, rot: int) -> Tuple[float, float]:
        """Rotated AABB footprint size (w_r, h_r) in grid units.

        Supports 0/90/180/270; 180 behaves like 0, 270 like 90.
        """
        r = cls._norm_rot(rot)
        if r in (90, 270):
            return (float(group.height), float(group.width))
        return (float(group.width), float(group.height))

    @staticmethod
    def rotate_point(dx: float, dy: float, rot: int) -> Tuple[float, float]:
        """Rotate a local point (dx,dy) by multiples of 90 degrees (counter-clockwise)."""
        r = int(rot) % 360
        if r % 90 != 0:
            raise ValueError(f"rot must be a multiple of 90 degrees, got {rot!r}")
        if r == 0:
            return (float(dx), float(dy))
        if r == 90:
            return (float(dy), -float(dx))
        if r == 180:
            return (-float(dx), -float(dy))
        if r == 270:
            return (-float(dy), float(dx))
        # unreachable due to mod 360
        return (float(dx), float(dy))

    def _recti_hits_invalid(self, rect: RectI, invalid: torch.Tensor) -> bool:
        """Return True if rect intersects any invalid cell in `invalid` (bool[H,W], True=invalid)."""
        x0, y0, x1, y1 = rect
        if x0 < 0 or y0 < 0 or x1 > self.grid_width or y1 > self.grid_height:
            return True
        if x0 >= x1 or y0 >= y1:
            return False
        return bool(torch.any(invalid[y0:y1, x0:x1]).item())

    def _body_rect_from_bl(self, *, gid: GroupId, x_bl: int, y_bl: int, rot: int) -> RectI:
        g = self.groups[gid]
        w, h = self.rotated_size(g, rot)
        kw = self._as_int(w, name="width")
        kh = self._as_int(h, name="height")
        x0 = self._as_int(x_bl, name="x")
        y0 = self._as_int(y_bl, name="y")
        return (x0, y0, x0 + kw, y0 + kh)

    # ---- public rect helpers (BL, integer, half-open) ----
    def body_rect_bl(self, *, gid: GroupId, x_bl: int, y_bl: int, rot: int) -> RectI:
        """Return body rect (x0,y0,x1,y1) for a pose in bottom-left integer coordinates."""
        rot_n = self._norm_rot(int(rot))
        return self._body_rect_from_bl(gid=gid, x_bl=int(x_bl), y_bl=int(y_bl), rot=rot_n)

    def placed_body_rect_bl(self, gid: GroupId) -> RectI:
        """Return placed body's rect (x0,y0,x1,y1) from stored BL pose in `self.positions`."""
        x_bl, y_bl, rot = self.positions[gid]
        return self.body_rect_bl(gid=gid, x_bl=int(x_bl), y_bl=int(y_bl), rot=int(rot))

    @staticmethod
    def _pad_rect_i(rect: RectI, *, cL: int, cR: int, cB: int, cT: int) -> RectI:
        x0, y0, x1, y1 = rect
        return (x0 - int(cL), y0 - int(cB), x1 + int(cR), y1 + int(cT))

    def center_from_bl(self, *, gid: GroupId, x_bl: int, y_bl: int, rot: int) -> Tuple[float, float]:
        """Return (cx,cy) center from bottom-left pose (x_bl,y_bl,rot) of rotated AABB.

        NOTE: Engine stores positions as bottom-left integer coordinates. Center is derived
        only for objective/features/visualization. Keeping this in one place avoids drift.
        """
        g = self.groups[gid]
        w, h = self.rotated_size(g, rot)
        return (float(x_bl) + float(w) / 2.0, float(y_bl) + float(h) / 2.0)

    def pose_center(self, gid: GroupId) -> Tuple[float, float]:
        """Return (cx,cy) center for an already-placed group from `self.positions`."""
        x_bl, y_bl, rot = self.positions[gid]
        return self.center_from_bl(gid=gid, x_bl=int(x_bl), y_bl=int(y_bl), rot=int(rot))

    def compute_enex(self, gid: GroupId) -> Tuple[float, float, float, float]:
        """Compute entry/exit coordinates for a placed group (center-based IO offsets)."""
        if gid not in self.positions:
            raise KeyError(f"compute_enex: gid not placed: {gid!r}")
        x_bl, y_bl, rot = self.positions[gid]
        r = self._norm_rot(int(rot))
        cx, cy = self.center_from_bl(gid=gid, x_bl=int(x_bl), y_bl=int(y_bl), rot=int(r))
        g = self.groups[gid]
        ent_dx, ent_dy = self.rotate_point(float(g.ent_rel_x), float(g.ent_rel_y), int(r))
        exi_dx, exi_dy = self.rotate_point(float(g.exi_rel_x), float(g.exi_rel_y), int(r))
        return (float(cx) + float(ent_dx), float(cy) + float(ent_dy), float(cx) + float(exi_dx), float(cy) + float(exi_dy))

    def estimate_delta_obj(self, *, gid: GroupId, x: object, y: object, rot: object):
        """배치 시 예상 Δcost (unscaled, raw).

        - scalar (int/float) 또는 batched torch.Tensor[M] 입력 지원.
        - is_placeable 체크 없이 빠른 계산.

        Delta = Δflow + Δcompactness:
        - Flow: EXIT(src) -> ENTRY(dst) directed L1
        - Compactness: bbox HPWL = 0.5*(dx+dy)
        
        반환: raw cost 변화량 (낮을수록 좋은 배치)
        
        Note: 기존에는 scaled를 반환했으나, 이제 unscaled 반환.
        scaled가 필요하면 estimate_reward() 사용.
        """
        scalar_input = not (torch.is_tensor(x) or torch.is_tensor(y) or torch.is_tensor(rot))
        if gid not in self.groups:
            raise KeyError(f"estimate_delta_obj(batch): unknown gid={gid!r}")
        if scalar_input:
            x = torch.tensor([float(x)], dtype=torch.float32, device=self.device)
            y = torch.tensor([float(y)], dtype=torch.float32, device=self.device)
            rot = torch.tensor([int(rot)], dtype=torch.long, device=self.device)
        if not (torch.is_tensor(x) and torch.is_tensor(y) and torch.is_tensor(rot)):
            raise TypeError("estimate_delta_obj(batch): x,y,rot must all be torch.Tensor (or all scalars)")

        x_bl = x.to(device=self.device).view(-1)
        y_bl = y.to(device=self.device).view(-1)
        r = rot.to(device=self.device).view(-1).to(dtype=torch.long)
        M = int(x_bl.numel())
        if int(y_bl.numel()) != M or int(r.numel()) != M:
            raise ValueError("estimate_delta_obj(batch): x,y,rot must have same length")

        # Normalize rotations to {0,90,180,270}
        r = torch.remainder(r, 360)
        if torch.any((r % 90) != 0):
            raise ValueError("estimate_delta_obj(batch): rot must be multiples of 90")

        g = self.groups[gid]
        w0 = float(g.width)
        h0 = float(g.height)
        is_swap = (r == 90) | (r == 270)
        w = torch.where(is_swap, torch.full((M,), h0, device=self.device), torch.full((M,), w0, device=self.device))
        h = torch.where(is_swap, torch.full((M,), w0, device=self.device), torch.full((M,), h0, device=self.device))

        cx = x_bl.to(dtype=torch.float32) + w.to(dtype=torch.float32) * 0.5
        cy = y_bl.to(dtype=torch.float32) + h.to(dtype=torch.float32) * 0.5

        # Rotate IO offsets (vectorized)
        ent_dx0 = float(g.ent_rel_x)
        ent_dy0 = float(g.ent_rel_y)
        exi_dx0 = float(g.exi_rel_x)
        exi_dy0 = float(g.exi_rel_y)

        r0 = (r == 0)
        r90 = (r == 90)
        r180 = (r == 180)
        r270 = (r == 270)

        ent_dx = torch.where(
            r0,
            torch.full((M,), ent_dx0, device=self.device),
            torch.where(
                r90,
                torch.full((M,), ent_dy0, device=self.device),
                torch.where(
                    r180,
                    torch.full((M,), -ent_dx0, device=self.device),
                    torch.full((M,), -ent_dy0, device=self.device),
                ),
            ),
        ).to(dtype=torch.float32)
        ent_dy = torch.where(
            r0,
            torch.full((M,), ent_dy0, device=self.device),
            torch.where(
                r90,
                torch.full((M,), -ent_dx0, device=self.device),
                torch.where(
                    r180,
                    torch.full((M,), -ent_dy0, device=self.device),
                    torch.full((M,), ent_dx0, device=self.device),
                ),
            ),
        ).to(dtype=torch.float32)

        exi_dx = torch.where(
            r0,
            torch.full((M,), exi_dx0, device=self.device),
            torch.where(
                r90,
                torch.full((M,), exi_dy0, device=self.device),
                torch.where(
                    r180,
                    torch.full((M,), -exi_dx0, device=self.device),
                    torch.full((M,), -exi_dy0, device=self.device),
                ),
            ),
        ).to(dtype=torch.float32)
        exi_dy = torch.where(
            r0,
            torch.full((M,), exi_dy0, device=self.device),
            torch.where(
                r90,
                torch.full((M,), -exi_dx0, device=self.device),
                torch.where(
                    r180,
                    torch.full((M,), -exi_dy0, device=self.device),
                    torch.full((M,), exi_dx0, device=self.device),
                ),
            ),
        ).to(dtype=torch.float32)

        cand_en_x = cx + ent_dx
        cand_en_y = cy + ent_dy
        cand_ex_x = cx + exi_dx
        cand_ex_y = cy + exi_dy

        # ---- Δflow: include outgoing (gid->p) and incoming (p->gid) edges for placed nodes ----
        placed_nodes = list(self.placed)
        if not placed_nodes:
            delta_flow = torch.zeros((M,), dtype=torch.float32, device=self.device)
        else:
            en_p: List[Tuple[float, float]] = []
            ex_p: List[Tuple[float, float]] = []
            w_out: List[float] = []
            w_in: List[float] = []
            for p in placed_nodes:
                enx, eny, exx, exy = self.compute_enex(p)
                en_p.append((float(enx), float(eny)))
                ex_p.append((float(exx), float(exy)))
                w_out.append(float(self.group_flow.get(gid, {}).get(p, 0.0)))
                w_in.append(float(self.group_flow.get(p, {}).get(gid, 0.0)))

            en_p_xy = torch.tensor(en_p, dtype=torch.float32, device=self.device)  # [P,2]
            ex_p_xy = torch.tensor(ex_p, dtype=torch.float32, device=self.device)  # [P,2]
            w_out_t = torch.tensor(w_out, dtype=torch.float32, device=self.device).view(1, -1)  # [1,P]
            w_in_t = torch.tensor(w_in, dtype=torch.float32, device=self.device).view(1, -1)  # [1,P]

            # out: EXIT(gid) -> ENTRY(p)
            dist_out = (cand_ex_x.view(-1, 1) - en_p_xy[:, 0].view(1, -1)).abs() + (
                cand_ex_y.view(-1, 1) - en_p_xy[:, 1].view(1, -1)
            ).abs()
            # in: EXIT(p) -> ENTRY(gid)
            dist_in = (ex_p_xy[:, 0].view(1, -1) - cand_en_x.view(-1, 1)).abs() + (
                ex_p_xy[:, 1].view(1, -1) - cand_en_y.view(-1, 1)
            ).abs()

            delta_flow = (dist_out * w_out_t).sum(dim=1) + (dist_in * w_in_t).sum(dim=1)

        # ---- Δcompactness: bbox HPWL change ----
        if not self.placed:
            cur_hpwl = torch.zeros((M,), dtype=torch.float32, device=self.device)
            # hpwl for a single rectangle does not depend on position: 0.5*(w+h)
            new_hpwl = 0.5 * (w.to(dtype=torch.float32) + h.to(dtype=torch.float32))
            delta_comp = new_hpwl - cur_hpwl
        else:
            cur_min_x = float("inf")
            cur_max_x = float("-inf")
            cur_min_y = float("inf")
            cur_max_y = float("-inf")
            for pgid in self.placed:
                px_bl, py_bl, prot = self.positions[pgid]
                pw, ph = self.rotated_size(self.groups[pgid], prot)
                cur_min_x = min(cur_min_x, float(px_bl))
                cur_max_x = max(cur_max_x, float(px_bl) + float(pw))
                cur_min_y = min(cur_min_y, float(py_bl))
                cur_max_y = max(cur_max_y, float(py_bl) + float(ph))
            cur_hpwl_scalar = 0.5 * ((cur_max_x - cur_min_x) + (cur_max_y - cur_min_y))

            cur_min_x_t = torch.full((M,), float(cur_min_x), dtype=torch.float32, device=self.device)
            cur_max_x_t = torch.full((M,), float(cur_max_x), dtype=torch.float32, device=self.device)
            cur_min_y_t = torch.full((M,), float(cur_min_y), dtype=torch.float32, device=self.device)
            cur_max_y_t = torch.full((M,), float(cur_max_y), dtype=torch.float32, device=self.device)

            cand_min_x = x_bl.to(dtype=torch.float32)
            cand_max_x = x_bl.to(dtype=torch.float32) + w.to(dtype=torch.float32)
            cand_min_y = y_bl.to(dtype=torch.float32)
            cand_max_y = y_bl.to(dtype=torch.float32) + h.to(dtype=torch.float32)

            new_min_x = torch.minimum(cur_min_x_t, cand_min_x)
            new_max_x = torch.maximum(cur_max_x_t, cand_max_x)
            new_min_y = torch.minimum(cur_min_y_t, cand_min_y)
            new_max_y = torch.maximum(cur_max_y_t, cand_max_y)
            new_hpwl = 0.5 * ((new_max_x - new_min_x) + (new_max_y - new_min_y))
            delta_comp = new_hpwl - float(cur_hpwl_scalar)

        delta = (delta_flow + delta_comp).to(dtype=torch.float32)
        if scalar_input:
            return float(delta[0].item())
        return delta

    def estimate_delta_cost(self, *, gid: GroupId, x: object, y: object, rot: object):
        """배치 시 예상 Δcost (unscaled, raw).
        
        score map, action 비교 등에 사용.
        반환: raw cost 변화량 (낮을수록 좋은 배치)
        """
        return self.estimate_delta_obj(gid=gid, x=x, y=y, rot=rot)

    def estimate_reward(self, *, gid: GroupId, x: object, y: object, rot: object):
        """배치 시 예상 reward.
        
        policy 학습, action selection 등에 사용.
        반환: -Δcost / cost_scale (높을수록 좋은 배치)
        """
        delta_cost = self.estimate_delta_obj(gid=gid, x=x, y=y, rot=rot)
        if torch.is_tensor(delta_cost):
            return -delta_cost / float(self.cost_scale)
        return -float(delta_cost) / float(self.cost_scale)

    def estimate_terminal_reward(self) -> float:
        """현재 상태의 예상 최종 reward (MCTS leaf 평가용).
        
        반환: -cal_total_cost() / cost_scale
        누적 reward와 동일한 스케일.
        """
        return -float(self.cal_total_cost()) / float(self.cost_scale)

    def try_place(self, gid: GroupId, x: float, y: float, rot: int) -> bool:
        """Place a group if feasible; returns True on success.

        This mirrors `env.py` semantics (positions/placed/remaining only).
        NOTE: Engine-internal cached maps are NOT updated here.
        Use `_apply_place(..., update_caches=True)` when you need cached-map consistency.
        """
        x_bl = self._as_int(x, name="x")
        y_bl = self._as_int(y, name="y")
        r = self._norm_rot(int(rot))
        if not self.is_placeable(gid, float(x_bl), float(y_bl), int(r)):
            return False
        self.positions[gid] = (int(x_bl), int(y_bl), int(r))
        self.placed.add(gid)
        if gid in self.remaining:
            self.remaining.remove(gid)
        return True

    def _apply_place(self, gid: GroupId, x: float, y: float, rot: int, *, update_caches: bool) -> None:
        """Internal: apply a placement and optionally update engine caches."""
        x_bl = self._as_int(x, name="x")
        y_bl = self._as_int(y, name="y")
        r = self._norm_rot(int(rot))
        self.positions[gid] = (int(x_bl), int(y_bl), int(r))
        self.placed.add(gid)
        if gid in self.remaining:
            self.remaining.remove(gid)
        if update_caches:
            self._paint_occupancy(gid, int(x_bl), int(y_bl), int(r))
            # Keep zone invalid consistent for the *next* group after any real placement.
            # This prevents stale `_zone_invalid` when callers use step_masked() (wrappers).
            self._update_zone_invalid_for_next()

    # ---- feasibility / objective ----
    def is_placeable(self, gid: GroupId, x: float, y: float, rot: int) -> bool:
        if gid not in self.groups:
            return False
        g = self.groups[gid]
        if not g.movable:
            return False
        if (not g.rotatable) and int(rot) != 0:
            rot = 0
        rot = self._norm_rot(int(rot))

        # IMPORTANT: (x,y) is bottom-left of rotated AABB in integer grid coordinates.
        x_bl = self._as_int(x, name="x")
        y_bl = self._as_int(y, name="y")

        rect = self._body_rect_from_bl(gid=gid, x_bl=x_bl, y_bl=y_bl, rot=rot)  # (x0,y0,x1,y1)

        # clearance rotation (int)
        cL, cR, cB, cT = self._clearance_lrtb(g, rot)
        rect_pad = self._pad_rect_i(rect, cL=int(cL), cR=int(cR), cB=int(cB), cT=int(cT))

        # boundary: BOTH body and pad must stay inside.
        # rect = (x0, y0, x1, y1)
        if rect[0] < 0 or rect[1] < 0 or rect[2] > self.grid_width or rect[3] > self.grid_height:
            return False
        if rect_pad[0] < 0 or rect_pad[1] < 0 or rect_pad[2] > self.grid_width or rect_pad[3] > self.grid_height:
            return False

        # body hits core invalid (static/occ/zone)
        if self._recti_hits_invalid(rect, self._invalid):
            return False
        # body hits others' clearance
        if self._recti_hits_invalid(rect, self._clear_invalid):
            return False
        # my clearance/pad hits static/occ/zone
        if self._recti_hits_invalid(rect_pad, self._invalid):
            return False

        return True

    def cal_obj(self) -> float:
        """Simple objective: weighted L1 flow distance + compactness.

        NOTE: This is a minimal version; you can replace with your notebook-accurate objective later.
        """
        if not self.placed:
            return 0.0

        total_distance = 0.0
        # Flow distance: EXIT(g1) -> ENTRY(g2) Manhattan distance (legacy behavior).
        enex_cache: Dict[GroupId, Tuple[float, float, float, float]] = {}
        for gid in self.placed:
            enex_cache[gid] = self.compute_enex(gid)
        for g1 in self.placed:
            _en1_x, _en1_y, ex1_x, ex1_y = enex_cache[g1]
            for g2, w in self.group_flow.get(g1, {}).items():
                if g2 not in self.placed:
                    continue
                en2_x, en2_y, _ex2_x, _ex2_y = enex_cache[g2]
                total_distance += float(w) * (abs(ex1_x - en2_x) + abs(ex1_y - en2_y))

        min_x = float("inf")
        max_x = float("-inf")
        min_y = float("inf")
        max_y = float("-inf")
        for gid in self.placed:
            x_bl, y_bl, rot = self.positions[gid]
            w, h = self.rotated_size(self.groups[gid], rot)
            min_x = min(min_x, float(x_bl))
            max_x = max(max_x, float(x_bl) + float(w))
            min_y = min(min_y, float(y_bl))
            max_y = max(max_y, float(y_bl) + float(h))
        compactness = 0.5 * ((max_x - min_x) + (max_y - min_y))
        return float(total_distance + compactness)

    def cal_total_cost(self) -> float:
        """통합 cost: objective + 미배치 페널티.
        
        - 완료된 레이아웃: cal_obj()와 동일 (페널티 0)
        - 미완료 레이아웃: cal_obj() + penalty_weight * remaining_ratio
        
        TopK 정렬 및 레이아웃 비교에 사용.
        최종 reward = -cal_total_cost / cost_scale 관계 성립.
        """
        base = self.cal_obj()
        penalty = float(self.penalty_weight) * self._remaining_area_ratio()
        return base + penalty

    def _remaining_area_ratio(self) -> float:
        """Remaining area / total area ratio in [0,1]. Mirrors env.py."""
        total_area = 0.0
        remaining_area = 0.0
        for gid, g in self.groups.items():
            a = float(g.width) * float(g.height)
            total_area += a
            if gid in self.remaining:
                remaining_area += a
        if total_area <= 0.0:
            return 1.0
        ratio = remaining_area / total_area
        if ratio < 0.0:
            return 0.0
        if ratio > 1.0:
            return 1.0
        return float(ratio)

    def _failure_penalty(self) -> float:
        """Penalty reward for failed placement or no valid actions (negative).
        
        스케일 통일: -(penalty_weight * remaining) / cost_scale
        이로써 최종 reward = -cal_total_cost / cost_scale 관계 성립.
        """
        raw_penalty = float(self.penalty_weight) * self._remaining_area_ratio()
        return -raw_penalty / float(self.cost_scale)
    
    # ---- Export API ----
    
    def export_placement(self) -> Dict[str, Any]:
        """현재 배치 상태를 JSON-serializable dict로 export.
        
        Returns:
            환경 설정 + 배치 정보 + 그룹 정보 + flow 정보
        """
        # 배치 정보
        placements = []
        for gid in self.placed:
            if gid in self.positions:
                x_bl, y_bl, rot = self.positions[gid]
                placements.append({
                    "gid": gid,
                    "x": int(x_bl),
                    "y": int(y_bl),
                    "rot": int(rot),
                })
        
        # 그룹 정보
        groups_data = {}
        for gid, g in self.groups.items():
            groups_data[gid] = {
                "width": float(g.width),
                "height": float(g.height),
                "rotatable": bool(g.rotatable),
                "clearance_left": float(getattr(g, 'clearance_left', 0)),
                "clearance_right": float(getattr(g, 'clearance_right', 0)),
                "clearance_bottom": float(getattr(g, 'clearance_bottom', 0)),
                "clearance_top": float(getattr(g, 'clearance_top', 0)),
                "ent_rel_x": float(getattr(g, 'ent_rel_x', 0)),
                "ent_rel_y": float(getattr(g, 'ent_rel_y', 0)),
                "exi_rel_x": float(getattr(g, 'exi_rel_x', 0)),
                "exi_rel_y": float(getattr(g, 'exi_rel_y', 0)),
            }
        
        # Flow 정보
        flow_edges = []
        for src, dsts in self.group_flow.items():
            for dst, weight in dsts.items():
                flow_edges.append([src, dst, float(weight)])
        
        return {
            "grid_width": int(self.grid_width),
            "grid_height": int(self.grid_height),
            "placements": placements,
            "groups": groups_data,
            "flow_edges": flow_edges,
            "forbidden_areas": list(self.forbidden_areas),
        }
    
    def save_placement(self, path: str) -> None:
        """배치 상태를 JSON 파일로 저장.
        
        Args:
            path: 저장할 파일 경로
        """
        import json
        data = self.export_placement()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _fail(
        self, reason: str, **extra: Any
    ) -> Tuple[Dict[str, torch.Tensor], float, bool, bool, Dict[str, Any]]:
        """실패 처리 통합 헬퍼."""
        reward = self._failure_penalty()
        info: Dict[str, Any] = {"reason": reason, "invalid": True}
        info.update(extra)

        if self.log:
            base_cost = float(self.cal_obj())
            penalty = float(self.penalty_weight) * self._remaining_area_ratio()
            total_cost = base_cost + penalty
            print(
                f"[env] fail: reason={reason} remaining={len(self.remaining)} "
                f"cost={total_cost:.3f} (base={base_cost:.3f} + penalty={penalty:.3f}) reward={reward:.3f}"
            )

        return self._build_obs(), float(reward), False, True, info

    # ---- cached maps ----
    def _build_static_invalid(self) -> torch.Tensor:
        inv = torch.zeros((self.grid_height, self.grid_width), dtype=torch.bool, device=self.device)
        # Build forbidden mask from forbidden_areas list
        for area in self.forbidden_areas:
            if not isinstance(area, dict) or "rect" not in area:
                continue
            rect = area["rect"]
            x0 = max(0, min(self.grid_width, int(rect[0])))
            x1 = max(0, min(self.grid_width, int(rect[2])))
            y0 = max(0, min(self.grid_height, int(rect[1])))
            y1 = max(0, min(self.grid_height, int(rect[3])))
            if x1 > x0 and y1 > y0:
                inv[y0:y1, x0:x1] = True
        return inv

    def _recompute_invalid(self) -> None:
        # invalid = static | occ | zone (NO new allocation)
        # Keep `self._invalid` as a persistent buffer and update it in-place to reduce
        # large temporary tensors / memory traffic.
        self._invalid.copy_(self._static_invalid)
        self._invalid.logical_or_(self._occ_invalid)
        self._invalid.logical_or_(self._zone_invalid)

    def _paint_occupancy(self, gid: GroupId, x_bl: int, y_bl: int, rot: int) -> None:
        """Paint occupancy and clearance maps for an already-validated placement.

        Inputs are bottom-left integer coordinates of the rotated AABB footprint.
        """
        rot = self._norm_rot(int(rot))
        rect = self._body_rect_from_bl(gid=gid, x_bl=int(x_bl), y_bl=int(y_bl), rot=rot)
        x0, y0, x1, y1 = rect
        if x0 < x1 and y0 < y1:
            self._occ_invalid[y0:y1, x0:x1] = True

        g = self.groups[gid]
        cL, cR, cB, cT = self._clearance_lrtb(g, rot)
        rect_pad = self._pad_rect_i(rect, cL=int(cL), cR=int(cR), cB=int(cB), cT=int(cT))
        px0, py0, px1, py1 = rect_pad
        if px0 < px1 and py0 < py1:
            self._clear_invalid[py0:py1, px0:px1] = True

        self._recompute_invalid()

    def _build_obs(self) -> Dict[str, torch.Tensor]:
        """Return *core* observation (model-agnostic).

        Policy-specific wrappers should attach their own extra observation fields
        on top of this core dict.
        """
        gid = self.remaining[0] if self.remaining else (self.node_ids[0] if self.node_ids else list(self.groups.keys())[0])
        g = self.groups[gid]

        N = int(len(self.node_ids))
        placed_mask = torch.zeros((N,), dtype=torch.bool, device=self.device)
        pos = torch.full((N, 3), -1, dtype=torch.long, device=self.device)  # (x_bl,y_bl,rot) or -1
        for gid2 in self.placed:
            idx = self.gid_to_idx.get(gid2, None)
            if idx is None:
                continue
            placed_mask[int(idx)] = True
            x_bl, y_bl, rot = self.positions[gid2]
            pos[int(idx), 0] = int(x_bl)
            pos[int(idx), 1] = int(y_bl)
            pos[int(idx), 2] = int(rot)

        # current gid index (static node list)
        cur_idx = int(self.gid_to_idx.get(gid, 0))

        obs: Dict[str, torch.Tensor] = {
            "current_gid_idx": torch.tensor([cur_idx], dtype=torch.long, device=self.device),
            # NOTE: normalized to canvas (grid) size for scale-stable learning.
            "next_group_wh": torch.tensor(
                [float(g.width) / float(self.grid_width), float(g.height) / float(self.grid_height)],
                dtype=torch.float32,
                device=self.device,
            ),
            "placed_mask": placed_mask,
            "positions_bl": pos,
            "step_count": torch.tensor([int(self._step_count)], dtype=torch.long, device=self.device),
        }
        return obs

    def step_action(
        self,
        *,
        x: float,
        y: float,
        rot: int,
        # 옵션: mask 관련 (없으면 검사 안함)
        action: Optional[int] = None,
        mask: Optional[torch.Tensor] = None,
        action_space_n: Optional[int] = None,
        extra_info: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, torch.Tensor], float, bool, bool, Dict[str, Any]]:
        """통합 step 메서드: 배치 시도 + 옵션 mask 검사.

        Args:
            x, y, rot: 배치 좌표 (bottom-left, rotation)
            action: (옵션) discrete action index (mask 검사용)
            mask: (옵션) action mask (True=valid)
            action_space_n: (옵션) action space 크기
            extra_info: (옵션) info에 추가할 정보
        """
        self._step_count += 1

        # 0. extra_info 처리
        info: Dict[str, Any] = {}
        if extra_info:
            info.update(dict(extra_info))

        # 1. 이미 완료된 경우
        if not self.remaining:
            return self._build_obs(), 0.0, True, False, {"reason": "done", "invalid": False}

        # 2. Mask 검사 (파라미터가 있을 때만)
        if mask is not None:
            if int(mask.to(torch.int64).sum().item()) == 0:
                return self._fail("no_valid_actions")
            if action is not None and action_space_n is not None:
                if int(action) < 0 or int(action) >= int(action_space_n):
                    return self._fail("action_out_of_range")
                if not bool(mask[int(action)].item()):
                    return self._fail("masked_action")

        # 3. 배치 시도
        gid = self.remaining[0]
        x_bl = self._as_int(x, name="x")
        y_bl = self._as_int(y, name="y")
        r = self._norm_rot(int(rot))

        if not self.is_placeable(gid, float(x_bl), float(y_bl), int(r)):
            return self._fail("not_placeable", gid=gid, x=int(x_bl), y=int(y_bl), rot=int(r))

        # 4. 성공 배치
        cost_prev = float(self.cal_obj())
        self._apply_place(gid, float(x_bl), float(y_bl), int(r), update_caches=True)
        cost_new = float(self.cal_obj())

        reward = -(cost_new - cost_prev) / float(self.cost_scale)
        terminated = len(self.remaining) == 0
        truncated = self.max_steps is not None and self._step_count >= self.max_steps

        info.update({
            "reason": "placed",
            "invalid": False,
            "gid": gid,
            "x": int(x_bl),
            "y": int(y_bl),
            "rot": int(r),
        })

        # 5. 로깅
        if self.log and (terminated or truncated):
            total_cost = self.cal_total_cost()
            print(
                f"[env] end: terminated={terminated} truncated={truncated} "
                f"remaining={len(self.remaining)} placed={len(self.placed)} step={self._step_count} "
                f"cost={total_cost:.3f} reason=placed reward={reward:.3f}"
            )

        return self._build_obs(), float(reward), bool(terminated), bool(truncated), info

    # --- Backward-compatible aliases ---
    def step_place(
        self, *, x: float, y: float, rot: int
    ) -> Tuple[Dict[str, torch.Tensor], float, bool, bool, Dict[str, Any]]:
        """단순 배치 API (backward-compatible). step_action() 호출."""
        return self.step_action(x=x, y=y, rot=rot)

    def step_masked(
        self,
        *,
        action: int,
        x: float,
        y: float,
        rot: int,
        mask: Optional[torch.Tensor],
        action_space_n: int,
        extra_info: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, torch.Tensor], float, bool, bool, Dict[str, Any]]:
        """Wrapper용 API (backward-compatible). step_action() 호출."""
        return self.step_action(
            x=x,
            y=y,
            rot=rot,
            action=action,
            mask=mask,
            action_space_n=action_space_n,
            extra_info=extra_info,
        )

    # ---- gym api ----
    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        super().reset(seed=seed)
        options = dict(options or {})
        initial_positions = options.get("initial_positions", None)
        remaining_order = options.get("remaining_order", None)

        self.positions = {}
        self.placed = set()

        # Base order: "harder-first" heuristic.
        #
        # TEMP (requested): difficulty = facility_area / free_area.
        # - invalid_area: inv.sum() where inv = static_only | zone_invalid_for_gid(gid)
        # - free_area: total_area - invalid_area
        # - facility_area: footprint area (w*h)
        # Larger difficulty => bigger footprint relative to available free space => placed earlier.
        #
        # TODO(ord1): Restore placeable(K/T) ordering using conv2d-based top-left feasibility.
        ordering: List[Tuple[float, float, GroupId, int]] = []
        static_only = self._static_invalid  # no occupancy at reset-time
        for gid in self.groups.keys():
            gg = self.groups[gid]
            inv = static_only | self._zone_invalid_for_gid(gid)
            facility_area = float(gg.width) * float(gg.height)
            # invalid_area (requested): true invalid area on grid (cell units; 1 cell == 1 area unit here)
            invalid_area = int(inv.to(torch.int64).sum().item())
            total_area = int(self.grid_width) * int(self.grid_height)
            free_area = max(1, int(total_area) - int(invalid_area))
            denom = float(free_area)
            difficulty = float(facility_area) / float(denom)
            ordering.append((difficulty, facility_area, gid, invalid_area))

        # Sort:
        # 1) difficulty descending (harder first)
        # 2) facility_area descending (bigger first among equally hard)
        # 3) gid for stable order
        ordering.sort(key=lambda t: (-t[0], -t[1], str(t[2])))
        base_remaining = [gid for _diff, _area, gid, _inv in ordering]

        if self.log:
            print("[reset_order] harder-first by difficulty (=facility_area/free_area)")
            for rank, (diff, area, gid, invalid_area) in enumerate(ordering, start=1):
                total_area = int(self.grid_width) * int(self.grid_height)
                free_area = max(1, int(total_area) - int(invalid_area))
                print(
                    f"  {rank}/{len(ordering)} gid={gid} "
                    f"facility_area={area:.1f} "
                    f"invalid_area={invalid_area} "
                    f"free_area={free_area} "
                    f"difficulty={diff:.6g}"
                )
        if remaining_order is not None:
            if not isinstance(remaining_order, list):
                raise ValueError("reset(options): remaining_order must be a list of group ids")
            # Validate remaining_order elements and uniqueness.
            seen = set()
            for gid in remaining_order:
                if gid not in self.groups:
                    raise ValueError(f"reset(options): remaining_order contains unknown group id: {gid!r}")
                if gid in seen:
                    raise ValueError(f"reset(options): remaining_order contains duplicate group id: {gid!r}")
                seen.add(gid)
            # Keep order provided, append missing groups by base order.
            rest = [gid for gid in base_remaining if gid not in seen]
            self.remaining = list(remaining_order) + rest
        else:
            self.remaining = list(base_remaining)

        self._step_count = 0
        self._occ_invalid.zero_()
        self._clear_invalid.zero_()
        self._zone_invalid.zero_()
        self._recompute_invalid()

        # Apply validated initial placements (and sync caches).
        if initial_positions is not None:
            if not isinstance(initial_positions, dict):
                raise ValueError("reset(options): initial_positions must be a dict {gid: (x,y,rot)}")
            for gid, pose in initial_positions.items():
                if gid not in self.groups:
                    raise ValueError(f"reset(options): initial_positions has unknown group id: {gid!r}")
                if (not isinstance(pose, (tuple, list))) or len(pose) != 3:
                    raise ValueError(f"reset(options): initial_positions[{gid!r}] must be (x,y,rot)")
                x = self._as_int(pose[0], name="x")
                y = self._as_int(pose[1], name="y")
                rot = self._norm_rot(int(pose[2]))
                if gid in self.placed:
                    raise ValueError(f"reset(options): initial_positions contains duplicate gid: {gid!r}")
                if not self.is_placeable(gid, float(x), float(y), int(rot)):
                    warnings.warn(
                        f"reset(options): invalid initial placement gid={gid!r} pose=({x},{y},{rot}) - placing anyway",
                        stacklevel=2,
                    )
                self._apply_place(gid, float(x), float(y), int(rot), update_caches=True)

            # Ensure invalid map is consistent (paint already recomputed, but keep invariant explicit).
            self._update_zone_invalid_for_next()

        # Apply next-gid dependent zones on fresh reset too.
        self._update_zone_invalid_for_next()
        return self._build_obs(), {}

    # ---- snapshot api (for search/MCTS) ----
    def get_snapshot(self) -> Dict[str, object]:
        """Return a deep-ish snapshot for deterministic restore in search algorithms.

        Notes:
        - This is additive (does not change training/inference behavior).
        - Tensors are cloned to ensure isolation across rollouts.
        """
        return {
            "positions": dict(self.positions),
            "placed": set(self.placed),
            "remaining": list(self.remaining),
            "_step_count": int(self._step_count),
            "_occ_invalid": self._occ_invalid.clone(),
            "_clear_invalid": self._clear_invalid.clone(),
            "_invalid": self._invalid.clone(),
            "_zone_invalid": self._zone_invalid.clone(),
        }

    def set_snapshot(self, snapshot: Dict[str, object]) -> None:
        """Restore a snapshot produced by `get_snapshot`."""
        self.positions = dict(snapshot.get("positions", {}))  # type: ignore[arg-type]
        self.placed = set(snapshot.get("placed", set()))  # type: ignore[arg-type]
        self.remaining = list(snapshot.get("remaining", []))  # type: ignore[arg-type]
        self._step_count = int(snapshot.get("_step_count", 0))

        occ = snapshot.get("_occ_invalid", None)
        clr = snapshot.get("_clear_invalid", None)
        inv = snapshot.get("_invalid", None)
        zinv = snapshot.get("_zone_invalid", None)
        if isinstance(occ, torch.Tensor):
            self._occ_invalid = occ.to(device=self.device, dtype=torch.bool).clone()
        if isinstance(clr, torch.Tensor):
            self._clear_invalid = clr.to(device=self.device, dtype=torch.bool).clone()
        if isinstance(zinv, torch.Tensor):
            self._zone_invalid = zinv.to(device=self.device, dtype=torch.bool).clone()
        # Recompute invalid from layers to keep invariant.
        self._recompute_invalid()

    def step(self, action: int):
        x, y, rot, i, j = self.decode_action(action)
        obs, reward, terminated, truncated, info = self.step_place(x=x, y=y, rot=rot)
        info.update({"cell_i": i, "cell_j": j})
        return obs, reward, terminated, truncated, info


if __name__ == "__main__":
    # Timing-focused smoke demo:
    # - env init time
    # - reset time
    # - one step time (any action; validity not required)
    import time

    dev = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    dev = torch.device("cpu")

    # --- groups: footprint + constraint attributes ---
    groups = {
        "A": FacilityGroup(id="A", width=20, height=10, rotatable=True, facility_weight=3.0, facility_height=2.0, facility_dry=0.0),
        "B": FacilityGroup(id="B", width=15, height=15, rotatable=True, facility_weight=4.0, facility_height=2.0, facility_dry=0.0),
        # Make C "heavy + tall + dry-sensitive" to exercise constraints.
        "C": FacilityGroup(id="C", width=18, height=12, rotatable=True, facility_weight=12.0, facility_height=10.0, facility_dry=2.0),
    }
    group_flow = {"A": {"B": 1.0}, "B": {"C": 0.7}}

    # Base forbidden area (now as list of rects).
    forbidden_areas = [{"rect": [0, 0, 30, 20]}]

    # Constraints (optional; unified default + area override):
    default_weight = 10.0
    # Right-half has higher allowable weight.
    weight_areas = [{"rect": (60, 0, 120, 80), "value": 20.0}]
    default_height = 20.0
    # Top strip has low ceiling height.
    height_areas = [{"rect": (0, 60, 120, 80), "value": 5.0}]
    default_dry = 0.0
    # Middle-left zone has higher dry requirement (reverse inequality).
    dry_areas = [{"rect": (0, 40, 60, 80), "value": 2.0}]

    t0 = time.perf_counter()
    env = FactoryLayoutEnv(
        grid_width=120,
        grid_height=80,
        groups=groups,
        group_flow=group_flow,
        forbidden_areas=forbidden_areas,
        device=dev,
        max_steps=10,
        log=True,
        weight_areas=weight_areas,
        height_areas=height_areas,
        dry_areas=dry_areas,
        default_weight=default_weight,
        default_height=default_height,
        default_dry=default_dry,
    )
    init_ms = (time.perf_counter() - t0) * 1000.0

    t1 = time.perf_counter()
    obs, _ = env.reset()
    reset_ms = (time.perf_counter() - t1) * 1000.0

    # Step with any arbitrary raw placement (we only care about step runtime here).
    # NOTE: This may be invalid/not_placeable; that's fine for this timing demo.
    t2 = time.perf_counter()
    obs2, reward, terminated, truncated, info = env.step_place(x=0.0, y=0.0, rot=0)
    step_ms = (time.perf_counter() - t2) * 1000.0

    print("[env_demo]")
    print(" device=", dev)
    print(f" init_ms={init_ms:.2f} reset_ms={reset_ms:.2f} step_ms={step_ms:.2f}")
    print(" placed_now=", len(env.placed), "remaining_now=", len(env.remaining))
    print(" step_info.reason=", info.get("reason"), "reward=", reward, "terminated=", terminated, "truncated=", truncated)
    print(" obs_keys=", list(obs.keys()))
    print(" obs2_keys=", list(obs2.keys()))

    # Optional visualization (interactive toggles).
    from envs.visualizer import plot_flow_graph, plot_layout

    plot_layout(env, candidate_set=None)
    plot_flow_graph(env)

